# MBODJI DigitalLab - Portfolio Website

Professional portfolio website for Youssoupha MBODJI - Regional GIS Technical Referent

## 🚀 Live Site

**[mbodjidigitallab.github.io](https://mbodjidigitallab.github.io)**

## ✨ Features

- **Interactive Career Map** - Leaflet maps showing all mission locations
- **Experience Timeline** - Detailed cards with achievements and metrics
- **Innovation Projects** - Showcase of digital solutions
- **Dark/Light Mode** - Automatic detection + manual toggle
- **Fully Responsive** - Mobile, tablet, desktop optimized
- **Smooth Animations** - Scroll-triggered animations
- **Contact Form** - Ready for integration

## 📁 Structure

```
mbodji-digital-lab/
├── index.html          # Main page
├── css/
│   └── style.css       # Complete styling
├── js/
│   ├── app.js          # Main application logic
│   └── map.js          # Leaflet map functionality
├── data/
│   └── experiences.json # Experience data (GeoJSON)
└── README.md           # This file
```

## 🛠️ Deployment to GitHub Pages

### Step 1: Create Repository
1. Go to GitHub → New Repository
2. Name: `mbodjidigitallab.github.io`
3. Public repository
4. Initialize with README

### Step 2: Upload Files
```bash
# Clone your repository
git clone https://github.com/yourusername/mbodjidigitallab.github.io.git

# Copy all files from this folder

# Commit and push
git add .
git commit -m "Initial portfolio deployment"
git push origin main
```

### Step 3: Enable GitHub Pages
1. Repository Settings → Pages
2. Source: Deploy from branch
3. Branch: main / root
4. Save

### Step 4: Access Your Site
Your site will be live at: `https://yourusername.github.io`

## 🎨 Customization

### Update Content
Edit `index.html` to update:
- Personal information
- Experience details
- Project descriptions
- Contact information

### Change Colors
Edit `css/style.css`:
```css
:root {
    --accent-primary: #00d4ff;
    --accent-secondary: #7b61ff;
    --accent-tertiary: #ff6b9d;
}
```

### Add Experiences
Edit `js/map.js` to add new entries to the `experiences` array.

## 📄 License

© 2026 Youssoupha MBODJI. All rights reserved.