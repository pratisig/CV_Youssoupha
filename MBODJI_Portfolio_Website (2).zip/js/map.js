/**
 * MBODJI DigitalLab - Leaflet Map Module
 * Interactive maps with country highlighting
 */

(function() {
    'use strict';

    const MAP_CONFIG = {
        tileLayer: 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
        center: [12, -5],
        zoom: 4,
        maxZoom: 18,
        minZoom: 2
    };

    // Experience locations
    const experiences = [
        {
            id: 'msf',
            title: 'GIS Regional Technical Referent',
            organization: 'Médecins Sans Frontières (MSF)',
            period: 'Apr 2025 – Present',
            location: 'Dakar, Senegal',
            coords: [14.7166, -17.4676],
            color: '#E63946',
            icon: 'fa-kit-medical',
            type: 'current',
            mission: 'Regional technical leadership across 13 missions in 7 countries.',
            achievements: ['AI Epidemiological Forecasting', 'Spatial Sampling Engine', 'Security Geofencing', 'ArcGIS–OsmAnd Integration', 'Regional GIS Standardization']
        },
        {
            id: 'icrc-regional',
            title: 'Regional GIS & Data Analytics Manager',
            organization: 'International Committee of the Red Cross (ICRC)',
            period: 'Aug 2020 – Jul 2021',
            location: 'Dakar, Senegal',
            coords: [14.7166, -17.4676],
            color: '#E76F51',
            icon: 'fa-earth-africa',
            type: 'regional',
            mission: 'Supervised 9 GIS Officers in 7 countries + technical support to 6 countries = 13 countries.',
            achievements: ['Team Leadership (9 GIS Officers)', 'Technical Support (6 countries)', 'Programme Dashboards', 'Cattle Tracking Innovation']
        },
        {
            id: 'inso',
            title: 'Information Manager',
            organization: 'International NGO Safety Organisation (INSO)',
            period: 'Aug 2024 – Mar 2025',
            location: 'Bangui, CAR',
            coords: [4.3947, 18.5582],
            color: '#457B9D',
            icon: 'fa-shield-halved',
            type: 'country',
            mission: 'Information Management for humanitarian security analysis.',
            achievements: ['Data Quality (99%+)', 'Automated Dashboards', 'Partner Training', 'Donor Reporting']
        },
        {
            id: 'icrc-mali',
            title: 'GIS & Data Analytics Officer',
            organization: 'International Committee of the Red Cross (ICRC)',
            period: 'Feb 2019 – Jul 2020',
            location: 'Bamako, Mali',
            coords: [12.6392, -8.0029],
            color: '#E76F51',
            icon: 'fa-map-marked-alt',
            type: 'country',
            mission: 'GIS and data analytics for humanitarian operations in Mali.',
            achievements: ['National Geospatial Database', 'Interactive Dashboards', 'Data Quality Framework']
        },
        {
            id: 'onas',
            title: 'GIS Data Integration Specialist',
            organization: 'Office National de l\'Assainissement (ONAS)',
            period: 'Nov 2017 – Jan 2019',
            location: 'Dakar, Senegal',
            coords: [14.7166, -17.4676],
            color: '#2A9D8F',
            icon: 'fa-water',
            type: 'earlier',
            mission: 'National sanitation GIS development.',
            achievements: ['Data Integration', 'Infrastructure Mapping']
        },
        {
            id: 'ird',
            title: 'GIS & Remote Sensing Specialist',
            organization: 'Institut de Recherche pour le Développement (IRD)',
            period: 'May 2017 – Aug 2017',
            location: 'Saint-Louis, Senegal',
            coords: [16.0179, -16.4897],
            color: '#264653',
            icon: 'fa-satellite',
            type: 'earlier',
            mission: 'Drone photogrammetry and remote sensing for agricultural research.',
            achievements: ['Drone Photogrammetry', 'Agricultural Mapping']
        }
    ];

    // ICRC countries - Supervised (had dedicated GIS Officer)
    const icrcSupervised = {
        'Senegal': { center: [14.4974, -14.4524], officer: 'GIS Officer based' },
        'Mali': { center: [17.5707, -3.9962], officer: 'GIS Officer based' },
        'Cameroon': { center: [7.3697, 12.3547], officer: 'GIS Officer based' },
        'Central African Republic': { center: [6.6111, 20.9394], officer: 'GIS Officer based' },
        'Nigeria': { center: [9.0820, 8.6753], officer: 'GIS Officer based' },
        'Libya': { center: [26.3351, 17.2283], officer: 'GIS Officer based' },
        'DR Congo': { center: [-4.0383, 21.7587], officer: 'GIS Officer based' }
    };

    // ICRC countries - Technical Support (no dedicated GIS Officer)
    const icrcSupported = {
        'Mauritania': { center: [21.0079, -10.9408] },
        'Burkina Faso': { center: [12.2383, -1.5197] },
        'Niger': { center: [17.6078, 8.0817] },
        'Cape Verde': { center: [16.5388, -23.0418] },
        'Guinea-Bissau': { center: [11.8037, -15.1804] },
        'Côte d\'Ivoire': { center: [7.5400, -5.5471] }
    };

    // MSF countries
    const msfCountries = {
        'Burkina Faso': { center: [12.2383, -1.5197] },
        'Cameroon': { center: [7.3697, 12.3547] },
        'Madagascar': { center: [-18.7669, 46.8691] },
        'Mali': { center: [17.5707, -3.9962] },
        'Mauritania': { center: [21.0079, -10.9408] },
        'Niger': { center: [17.6078, 8.0817] },
        'Nigeria': { center: [9.0820, 8.6753] }
    };

    // ==========================================
    // CUSTOM ICONS
    // ==========================================
    function createCustomIcon(color, iconClass, size = 40) {
        const iconHtml = `
            <div style="
                background: ${color};
                width: ${size}px;
                height: ${size}px;
                border-radius: 50%;
                display: flex;
                align-items: center;
                justify-content: center;
                box-shadow: 0 4px 15px ${color}66;
                border: 3px solid white;
                position: relative;
            ">
                <i class="fas ${iconClass}" style="color: white; font-size: ${size * 0.4}px;"></i>
            </div>
        `;
        
        return L.divIcon({
            html: iconHtml,
            className: 'custom-marker',
            iconSize: [size, size],
            iconAnchor: [size/2, size],
            popupAnchor: [0, -(size + 5)]
        });
    }

    // ==========================================
    // POPUP CONTENT - Rich popups
    // ==========================================
    function createPopupContent(exp) {
        const lang = localStorage.getItem('lang') || 'en';
        const achievementsHtml = exp.achievements.map(a => `
            <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 4px;">
                <i class="fas fa-check-circle" style="color: ${exp.color}; font-size: 11px;"></i>
                <span style="font-size: 11px;">${a}</span>
            </div>
        `).join('');

        return `
            <div style="min-width: 280px; max-width: 320px; font-family: 'Inter', sans-serif; padding: 4px;">
                <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 12px; padding-bottom: 10px; border-bottom: 2px solid ${exp.color}30;">
                    <div style="background: ${exp.color}; width: 40px; height: 40px; border-radius: 10px; display: flex; align-items: center; justify-content: center;">
                        <i class="fas ${exp.icon}" style="color: white; font-size: 18px;"></i>
                    </div>
                    <div>
                        <h3 style="margin: 0; font-size: 13px; font-weight: 700; color: #1a1a1a;">${exp.title}</h3>
                        <p style="margin: 2px 0 0; font-size: 11px; color: ${exp.color}; font-weight: 600;">${exp.organization}</p>
                    </div>
                </div>
                
                <div style="display: flex; gap: 12px; margin-bottom: 8px; font-size: 10px; color: #666;">
                    <span><i class="fas fa-calendar" style="color: ${exp.color};"></i> ${exp.period}</span>
                    <span><i class="fas fa-map-marker-alt" style="color: ${exp.color};"></i> ${exp.location}</span>
                </div>
                
                <p style="font-size: 11px; color: #555; line-height: 1.5; margin-bottom: 10px; font-style: italic;">${exp.mission}</p>
                
                <div style="background: #f8f9fa; border-radius: 8px; padding: 10px;">
                    <div style="font-size: 10px; font-weight: 700; color: ${exp.color}; margin-bottom: 6px; text-transform: uppercase; letter-spacing: 1px;">
                        <i class="fas fa-trophy"></i> ${lang === 'fr' ? 'Réalisations Clés' : 'Key Achievements'}
                    </div>
                    ${achievementsHtml}
                </div>
            </div>
        `;
    }

    function createCountryPopup(countryName, type, details) {
        const lang = localStorage.getItem('lang') || 'en';
        const color = type === 'supervised' ? '#E76F51' : '#F4A261';
        const typeLabel = type === 'supervised' 
            ? (lang === 'fr' ? 'Supervisé directement' : 'Directly Supervised')
            : (lang === 'fr' ? 'Support technique' : 'Technical Support');
        const typeDesc = type === 'supervised'
            ? (lang === 'fr' ? 'Officier SIG dédié basé dans le pays' : 'Dedicated GIS Officer based in country')
            : (lang === 'fr' ? 'Support technique à distance et sur site' : 'Remote and on-site technical support');
        
        return `
            <div style="min-width: 220px; font-family: 'Inter', sans-serif; padding: 4px;">
                <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 10px;">
                    <div style="background: ${color}; width: 32px; height: 32px; border-radius: 8px; display: flex; align-items: center; justify-content: center;">
                        <i class="fas fa-flag" style="color: white; font-size: 14px;"></i>
                    </div>
                    <div>
                        <h3 style="margin: 0; font-size: 13px; font-weight: 700; color: #1a1a1a;">${countryName}</h3>
                        <p style="margin: 2px 0 0; font-size: 10px; color: ${color}; font-weight: 600;">${typeLabel}</p>
                    </div>
                </div>
                <p style="font-size: 11px; color: #555; margin-bottom: 8px;">${typeDesc}</p>
                <div style="font-size: 10px; color: #888; border-top: 1px solid #eee; padding-top: 6px;">
                    <i class="fas fa-building" style="color: ${color};"></i> ICRC Regional — ${lang === 'fr' ? 'Dakar, Sénégal' : 'Dakar, Senegal'}
                </div>
            </div>
        `;
    }

    // ==========================================
    // EXPERIENCE MAP
    // ==========================================
    function initExperienceMap() {
        const mapContainer = document.getElementById('experience-map');
        if (!mapContainer) return;

        const map = L.map('experience-map', {
            center: MAP_CONFIG.center,
            zoom: MAP_CONFIG.zoom,
            maxZoom: MAP_CONFIG.maxZoom,
            minZoom: MAP_CONFIG.minZoom
        });

        L.tileLayer(MAP_CONFIG.tileLayer, {
            attribution: MAP_CONFIG.attribution,
            maxZoom: MAP_CONFIG.maxZoom
        }).addTo(map);

        // Store layers for filtering
        const supervisedLayer = L.layerGroup().addTo(map);
        const supportedLayer = L.layerGroup().addTo(map);
        const markerLayer = L.layerGroup().addTo(map);

        // Add ICRC Supervised countries (highlighted with darker color)
        Object.entries(icrcSupervised).forEach(([name, data]) => {
            const circle = L.circleMarker(data.center, {
                radius: 25,
                color: '#E76F51',
                fillColor: '#E76F51',
                fillOpacity: 0.25,
                weight: 2,
                dashArray: null
            });
            circle.bindPopup(createCountryPopup(name, 'supervised', data));
            circle.bindTooltip(name, { permanent: false, direction: 'center' });
            supervisedLayer.addLayer(circle);
        });

        // Add ICRC Supported countries (lighter color)
        Object.entries(icrcSupported).forEach(([name, data]) => {
            const circle = L.circleMarker(data.center, {
                radius: 20,
                color: '#F4A261',
                fillColor: '#F4A261',
                fillOpacity: 0.15,
                weight: 1.5,
                dashArray: '5, 5'
            });
            circle.bindPopup(createCountryPopup(name, 'supported', data));
            circle.bindTooltip(name, { permanent: false, direction: 'center' });
            supportedLayer.addLayer(circle);
        });

        // Add MSF countries
        Object.entries(msfCountries).forEach(([name, data]) => {
            const circle = L.circleMarker(data.center, {
                radius: 22,
                color: '#E63946',
                fillColor: '#E63946',
                fillOpacity: 0.2,
                weight: 2,
                dashArray: '8, 4'
            });
            const lang = localStorage.getItem('lang') || 'en';
            const popupContent = `
                <div style="font-family: 'Inter', sans-serif; padding: 4px;">
                    <h3 style="margin: 0 0 4px; font-size: 13px; color: #E63946;">${name}</h3>
                    <p style="margin: 0; font-size: 11px; color: #555;">${lang === 'fr' ? 'Mission MSF couverte' : 'MSF mission covered'}</p>
                </div>
            `;
            circle.bindPopup(popupContent);
            circle.bindTooltip(name, { permanent: false, direction: 'center' });
            markerLayer.addLayer(circle);
        });

        // Add experience markers
        const markers = [];
        experiences.forEach(exp => {
            const marker = L.marker(exp.coords, {
                icon: createCustomIcon(exp.color, exp.icon),
                riseOnHover: true
            });
            marker.bindPopup(createPopupContent(exp), { maxWidth: 350, className: 'custom-popup' });
            marker.expData = exp;
            markerLayer.addLayer(marker);
            markers.push(marker);
        });

        // Add connection lines from Dakar to regional responsibilities
        const dakar = [14.7166, -17.4676];
        experiences.filter(e => e.id !== 'msf' && e.id !== 'icrc-regional' && e.id !== 'onas').forEach(exp => {
            L.polyline([dakar, exp.coords], {
                color: exp.color,
                weight: 1,
                opacity: 0.2,
                dashArray: '5, 10'
            }).addTo(map);
        });

        // Fit bounds
        const allCoords = [
            ...experiences.map(e => e.coords),
            ...Object.values(icrcSupervised).map(d => d.center),
            ...Object.values(icrcSupported).map(d => d.center),
            ...Object.values(msfCountries).map(d => d.center)
        ];
        map.fitBounds(L.latLngBounds(allCoords), { padding: [40, 40] });

        // Filter controls
        const filterBtns = document.querySelectorAll('.map-btn');
        filterBtns.forEach(btn => {
            btn.addEventListener('click', function() {
                const filter = this.dataset.filter;
                filterBtns.forEach(b => b.classList.remove('active'));
                this.classList.add('active');

                if (filter === 'all') {
                    map.addLayer(supervisedLayer);
                    map.addLayer(supportedLayer);
                    map.addLayer(markerLayer);
                } else if (filter === 'supervised') {
                    map.addLayer(supervisedLayer);
                    map.removeLayer(supportedLayer);
                    map.addLayer(markerLayer);
                } else if (filter === 'supported') {
                    map.removeLayer(supervisedLayer);
                    map.addLayer(supportedLayer);
                    map.addLayer(markerLayer);
                }
            });
        });

        setTimeout(() => map.invalidateSize(), 300);
        window.addEventListener('resize', () => map.invalidateSize());
    }

    // ==========================================
    // INITIALIZE
    // ==========================================
    function init() {
        if (typeof L === 'undefined') {
            setTimeout(init, 100);
            return;
        }
        initExperienceMap();
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

    window.addEventListener('load', () => setTimeout(init, 500));

})();