/**
 * MBODJI DigitalLab - Leaflet Map Module
 * Interactive maps for experience and about sections
 */

(function() {
    'use strict';

    // ==========================================
    // CONFIGURATION
    // ==========================================
    const MAP_CONFIG = {
        accessToken: null, // Not needed for OpenStreetMap
        tileLayer: 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
        center: [12, 0], // West Africa center
        zoom: 4,
        maxZoom: 18,
        minZoom: 2
    };

    // Experience data
    const experiences = [
        {
            id: 'msf',
            title: 'GIS Regional Technical Referent',
            organization: 'Médecins Sans Frontières (MSF)',
            period: 'Apr 2025 – Present',
            location: 'Dakar, Senegal',
            coords: [14.7166, -17.4676],
            color: '#E63946',
            icon: 'fa-kit-medical',
            countries: ['Burkina Faso', 'Cameroon', 'Madagascar', 'Mali', 'Mauritania', 'Niger', 'Nigeria'],
            mission: 'Provide regional technical leadership in Geospatial Information Management across 13 humanitarian missions.',
            achievements: [
                { icon: 'fa-brain', text: 'AI Epidemiological Forecasting - 2-6 weeks early warning' },
                { icon: 'fa-crosshairs', text: 'Spatial Sampling Engine for vaccination campaigns' },
                { icon: 'fa-shield-halved', text: 'Security Geofencing System - Real-time alerts' },
                { icon: 'fa-map-location-dot', text: 'ArcGIS–OsmAnd Integration for offline navigation' },
                { icon: 'fa-gears', text: 'Regional GIS Standardization across 7 countries' }
            ],
            type: 'humanitarian'
        },
        {
            id: 'inso',
            title: 'Information Manager',
            organization: 'International NGO Safety Organisation (INSO)',
            period: 'Aug 2024 – Mar 2025',
            location: 'Bangui, Central African Republic',
            coords: [4.3947, 18.5582],
            color: '#457B9D',
            icon: 'fa-shield-halved',
            countries: ['Central African Republic'],
            mission: 'Led the Information Management function supporting humanitarian access and security analysis.',
            achievements: [
                { icon: 'fa-database', text: 'Data Quality: 99%+ validated records' },
                { icon: 'fa-chart-bar', text: 'Automated dashboards for security analysis' },
                { icon: 'fa-graduation-cap', text: 'Partner capacity building and training' },
                { icon: 'fa-file-contract', text: 'Donor reporting for ECHO, BHA, SDC' }
            ],
            type: 'humanitarian'
        },
        {
            id: 'icrc-regional',
            title: 'Regional GIS & Data Analytics Manager',
            organization: 'International Committee of the Red Cross (ICRC)',
            period: 'Aug 2020 – Jul 2021',
            location: 'Dakar, Senegal',
            coords: [14.7166, -17.4676],
            color: '#E76F51',
            icon: 'fa-earth-africa',
            countries: ['Burkina Faso', 'Côte d\'Ivoire', 'Guinea-Bissau', 'Mauritania', 'Niger', 'Senegal'],
            mission: 'Regional leadership for GIS and Data Analytics across 12 humanitarian delegations.',
            achievements: [
                { icon: 'fa-globe', text: 'Coordinated GIS support across 12 delegations' },
                { icon: 'fa-chart-pie', text: 'Programme dashboards for WatHab, Protection, etc.' },
                { icon: 'fa-paw', text: 'Cattle Tracking Innovation project' }
            ],
            type: 'humanitarian'
        },
        {
            id: 'icrc-mali',
            title: 'GIS & Data Analytics Officer',
            organization: 'International Committee of the Red Cross (ICRC)',
            period: 'Feb 2019 – Jul 2020',
            location: 'Bamako, Mali',
            coords: [12.6392, -8.0029],
            color: '#E76F51',
            icon: 'fa-map-marked-alt',
            countries: ['Mali'],
            mission: 'Supported humanitarian operations with geospatial solutions for programme monitoring.',
            achievements: [
                { icon: 'fa-database', text: 'National geospatial reference database' },
                { icon: 'fa-tachometer-alt', text: 'Interactive programme dashboards' },
                { icon: 'fa-check-double', text: 'Data quality standardization' }
            ],
            type: 'humanitarian'
        },
        {
            id: 'onas',
            title: 'GIS Data Integration Specialist',
            organization: 'Office National de l\'Assainissement (ONAS)',
            period: 'Nov 2017 – Jan 2019',
            location: 'Dakar, Senegal',
            coords: [14.7166, -17.4676],
            color: '#2A9D8F',
            icon: 'fa-water',
            countries: ['Senegal'],
            mission: 'Supported national sanitation GIS through data integration and infrastructure mapping.',
            achievements: [
                { icon: 'fa-layer-group', text: 'National sanitation GIS database' },
                { icon: 'fa-map', text: 'Operational mapping for infrastructure' }
            ],
            type: 'research'
        },
        {
            id: 'ird',
            title: 'GIS & Remote Sensing Specialist',
            organization: 'Institut de Recherche pour le Développement (IRD)',
            period: 'May 2017 – Aug 2017',
            location: 'Saint-Louis, Senegal',
            coords: [16.0179, -16.4897],
            color: '#264653',
            icon: 'fa-satellite',
            countries: ['Senegal'],
            mission: 'Supported agricultural research through drone photogrammetry and remote sensing.',
            achievements: [
                { icon: 'fa-helicopter', text: 'Drone photogrammetry and orthomosaics' },
                { icon: 'fa-seedling', text: 'Agricultural parcel mapping' }
            ],
            type: 'research'
        },
        {
            id: 'saed',
            title: 'GIS Intern',
            organization: 'SAED',
            period: 'Feb 2015 – May 2015',
            location: 'Saint-Louis, Senegal',
            coords: [16.0179, -16.4897],
            color: '#E9C46A',
            icon: 'fa-tractor',
            countries: ['Senegal'],
            mission: 'Supported geospatial data collection for irrigation and agricultural development.',
            achievements: [
                { icon: 'fa-map', text: 'Thematic maps for agricultural development' }
            ],
            type: 'research'
        },
        {
            id: 'inp',
            title: 'Environmental Research Intern',
            organization: 'Institut National de Pédologie',
            period: 'Aug 2013 – Dec 2013',
            location: 'Ndiaffate, Senegal',
            coords: [13.8500, -15.8667],
            color: '#606C38',
            icon: 'fa-leaf',
            countries: ['Senegal'],
            mission: 'Conducted field surveys on mangrove regeneration and environmental monitoring.',
            achievements: [
                { icon: 'fa-tree', text: 'Mangrove regeneration research' }
            ],
            type: 'research'
        }
    ];

    // Country coordinates for coverage visualization
    const countryCoords = {
        'Burkina Faso': [12.2383, -1.5197],
        'Cameroon': [7.3697, 12.3547],
        'Madagascar': [-18.7669, 46.8691],
        'Mali': [17.5707, -3.9962],
        'Mauritania': [21.0079, -10.9408],
        'Niger': [17.6078, 8.0817],
        'Nigeria': [9.0820, 8.6753],
        'Central African Republic': [6.6111, 20.9394],
        'Côte d\'Ivoire': [7.5400, -5.5471],
        'Guinea-Bissau': [11.8037, -15.1804],
        'Senegal': [14.4974, -14.4524],
        'Libya': [26.3351, 17.2283],
        'DRC': [-4.0383, 21.7587]
    };

    // ==========================================
    // CUSTOM ICONS
    // ==========================================
    function createCustomIcon(color, iconClass) {
        const iconHtml = `
            <div style="
                background: ${color};
                width: 40px;
                height: 40px;
                border-radius: 50%;
                display: flex;
                align-items: center;
                justify-content: center;
                box-shadow: 0 4px 15px ${color}66;
                border: 3px solid white;
                position: relative;
            ">
                <i class="fas ${iconClass}" style="color: white; font-size: 16px;"></i>
            </div>
        `;
        
        return L.divIcon({
            html: iconHtml,
            className: 'custom-marker',
            iconSize: [40, 40],
            iconAnchor: [20, 40],
            popupAnchor: [0, -45]
        });
    }

    // ==========================================
    // POPUP CONTENT
    // ==========================================
    function createPopupContent(exp) {
        const achievementsHtml = exp.achievements.map(a => `
            <div style="display: flex; align-items: flex-start; gap: 8px; margin-bottom: 6px;">
                <i class="fas ${a.icon}" style="color: ${exp.color}; font-size: 12px; margin-top: 2px; min-width: 14px;"></i>
                <span style="font-size: 12px; line-height: 1.3;">${a.text}</span>
            </div>
        `).join('');

        const countriesHtml = exp.countries ? `
            <div style="margin-top: 10px; padding-top: 10px; border-top: 1px solid #eee;">
                <div style="font-size: 11px; color: #666; margin-bottom: 4px;">
                    <i class="fas fa-globe-africa" style="color: ${exp.color};"></i> Countries:
                </div>
                <div style="display: flex; flex-wrap: wrap; gap: 4px;">
                    ${exp.countries.map(c => `<span style="
                        background: ${exp.color}15;
                        color: ${exp.color};
                        padding: 2px 8px;
                        border-radius: 12px;
                        font-size: 10px;
                        border: 1px solid ${exp.color}30;
                    ">${c}</span>`).join('')}
                </div>
            </div>
        ` : '';

        return `
            <div style="min-width: 280px; max-width: 350px; font-family: 'Inter', sans-serif;">
                <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 12px; padding-bottom: 12px; border-bottom: 2px solid ${exp.color}20;">
                    <div style="
                        background: ${exp.color};
                        width: 45px;
                        height: 45px;
                        border-radius: 12px;
                        display: flex;
                        align-items: center;
                        justify-content: center;
                    ">
                        <i class="fas ${exp.icon}" style="color: white; font-size: 20px;"></i>
                    </div>
                    <div>
                        <h3 style="margin: 0; font-size: 14px; font-weight: 700; color: #1a1a1a;">
                            ${exp.title}
                        </h3>
                        <p style="margin: 2px 0 0; font-size: 12px; color: ${exp.color}; font-weight: 600;">
                            ${exp.organization}
                        </p>
                    </div>
                </div>
                
                <div style="display: flex; gap: 12px; margin-bottom: 10px; font-size: 11px; color: #666;">
                    <span><i class="fas fa-calendar" style="color: ${exp.color};"></i> ${exp.period}</span>
                    <span><i class="fas fa-map-marker-alt" style="color: ${exp.color};"></i> ${exp.location}</span>
                </div>
                
                <p style="font-size: 12px; color: #555; line-height: 1.5; margin-bottom: 12px; font-style: italic;">
                    ${exp.mission}
                </p>
                
                <div style="background: #f8f9fa; border-radius: 8px; padding: 10px;">
                    <div style="font-size: 11px; font-weight: 700; color: ${exp.color}; margin-bottom: 8px; text-transform: uppercase; letter-spacing: 1px;">
                        <i class="fas fa-trophy"></i> Key Achievements
                    </div>
                    ${achievementsHtml}
                </div>
                
                ${countriesHtml}
                
                <div style="margin-top: 12px; text-align: center;">
                    <a href="#experience" style="
                        display: inline-block;
                        background: ${exp.color};
                        color: white;
                        padding: 6px 16px;
                        border-radius: 6px;
                        font-size: 11px;
                        text-decoration: none;
                        font-weight: 600;
                    ">View Full Details</a>
                </div>
            </div>
        `;
    }

    // ==========================================
    // ABOUT MAP (Mini map showing coverage)
    // ==========================================
    function initAboutMap() {
        const mapContainer = document.getElementById('about-map');
        if (!mapContainer) return;

        const map = L.map('about-map', {
            center: [12, -5],
            zoom: 4,
            zoomControl: false,
            attributionControl: false,
            scrollWheelZoom: false,
            dragging: true
        });

        L.tileLayer(MAP_CONFIG.tileLayer, {
            attribution: MAP_CONFIG.attribution,
            maxZoom: MAP_CONFIG.maxZoom
        }).addTo(map);

        // Add markers for each location
        experiences.forEach(exp => {
            const marker = L.marker(exp.coords, {
                icon: createCustomIcon(exp.color, exp.icon)
            }).addTo(map);

            marker.bindTooltip(exp.location, {
                permanent: false,
                direction: 'top',
                offset: [0, -45]
            });
        });

        // Add country coverage circles
        const msfCountries = ['Burkina Faso', 'Cameroon', 'Madagascar', 'Mali', 'Mauritania', 'Niger', 'Nigeria'];
        msfCountries.forEach(country => {
            if (countryCoords[country]) {
                L.circleMarker(countryCoords[country], {
                    radius: 20,
                    color: '#E63946',
                    fillColor: '#E63946',
                    fillOpacity: 0.1,
                    weight: 1,
                    dashArray: '5, 5'
                }).addTo(map);
            }
        });

        // Fit bounds to show all markers
        const bounds = L.latLngBounds(experiences.map(e => e.coords));
        map.fitBounds(bounds, { padding: [30, 30] });

        // Fix map rendering issues
        setTimeout(() => map.invalidateSize(), 300);
    }

    // ==========================================
    // EXPERIENCE MAP (Main interactive map)
    // ==========================================
    function initExperienceMap() {
        const mapContainer = document.getElementById('experience-map');
        if (!mapContainer) return;

        const map = L.map('experience-map', {
            center: MAP_CONFIG.center,
            zoom: MAP_CONFIG.zoom,
            maxZoom: MAP_CONFIG.maxZoom,
            minZoom: MAP_CONFIG.minZoom,
            zoomControl: true,
            attributionControl: true
        });

        L.tileLayer(MAP_CONFIG.tileLayer, {
            attribution: MAP_CONFIG.attribution,
            maxZoom: MAP_CONFIG.maxZoom
        }).addTo(map);

        // Store markers for filtering
        const markers = [];

        // Add markers
        experiences.forEach(exp => {
            const marker = L.marker(exp.coords, {
                icon: createCustomIcon(exp.color, exp.icon),
                riseOnHover: true
            }).addTo(map);

            marker.bindPopup(createPopupContent(exp), {
                maxWidth: 350,
                className: 'custom-popup'
            });

            // Store reference for filtering
            marker.expData = exp;
            markers.push(marker);

            // Click handler to scroll to card
            marker.on('click', function() {
                const card = document.querySelector(`[data-org="${exp.id}"]`);
                if (card) {
                    setTimeout(() => {
                        card.scrollIntoView({ behavior: 'smooth', block: 'center' });
                        card.classList.add('highlight');
                        setTimeout(() => card.classList.remove('highlight'), 2000);
                    }, 500);
                }
            });
        });

        // Add coverage lines from Dakar to each mission
        const dakarCoords = [14.7166, -17.4676];
        experiences.filter(e => e.id !== 'msf' && e.id !== 'icrc-regional' && e.id !== 'onas').forEach(exp => {
            L.polyline([dakarCoords, exp.coords], {
                color: exp.color,
                weight: 1,
                opacity: 0.3,
                dashArray: '5, 10'
            }).addTo(map);
        });

        // Fit bounds
        const bounds = L.latLngBounds(experiences.map(e => e.coords));
        map.fitBounds(bounds, { padding: [50, 50] });

        // Filter controls
        const filterBtns = document.querySelectorAll('.map-btn');
        filterBtns.forEach(btn => {
            btn.addEventListener('click', function() {
                const filter = this.dataset.filter;
                
                // Update active button
                filterBtns.forEach(b => b.classList.remove('active'));
                this.classList.add('active');

                // Filter markers
                markers.forEach(marker => {
                    if (filter === 'all' || marker.expData.type === filter) {
                        marker.addTo(map);
                    } else {
                        map.removeLayer(marker);
                    }
                });
            });
        });

        // Fix map rendering
        setTimeout(() => map.invalidateSize(), 300);

        // Add resize handler
        window.addEventListener('resize', () => {
            map.invalidateSize();
        });
    }

    // ==========================================
    // INITIALIZE
    // ==========================================
    function init() {
        // Wait for DOM and Leaflet to load
        if (typeof L === 'undefined') {
            console.warn('Leaflet not loaded. Retrying...');
            setTimeout(init, 100);
            return;
        }

        initAboutMap();
        initExperienceMap();
    }

    // Start when DOM is ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

    // Also try on window load as fallback
    window.addEventListener('load', () => {
        setTimeout(init, 500);
    });

})();